/** Automatically generated file. DO NOT MODIFY */
package course.labs.notificationslab.tests;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}